# 🛡️ Jaglotl Warcraft Kingdom: Celestial Dominion Protocol

[![Node.js](https://img.shields.io/badge/Node.js-16.x+-green.svg)](https://nodejs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-4.5+-blue.svg)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/License-Proprietary-red.svg)](#license)
[![Build Status](https://img.shields.io/badge/Build-Passing-brightgreen.svg)]()

> *“I scattered myself across four realms not from weakness, but from love. What you reassemble may not think as one...”*  
> — Final inscription from Sigeralarlotl's Shattered Throne

---

## 🧠 Project Overview

**Jaglotl Warcraft Kingdom** is a transcendent NFT-based cosmic warfare saga where players inherit fragments of a god’s consciousness to command celestial hybrid armies. This isn't just another creature collector – it’s **psychological evolution**, shifting from mythic lore to existential cosmic horror.

---

## 🔍 What Makes This Different

- **🎮 Professional Game Engine**: Enterprise-grade TypeScript architecture  
- **🧬 Psychological Transformation**: Collection evolves from cute to cosmic horror  
- **⚙️ True Utility**: Every NFT powers actual game mechanics  
- **📖 Cosmic Horror Narrative**: Lovecraftian themes through interactive storytelling  
- **🔗 Blockchain Integration**: MetaMask wallet connectivity with multi-token economy

---

## 🚀 Quick Start

### Prerequisites

- ✅ Node.js 16.x or higher  
- ✅ Git  
- ✅ Visual Studio Code (recommended)  
- ✅ MetaMask wallet  

---

## 🏗️ Project Structure

| Folder         | Purpose                                                                 |
|----------------|-------------------------------------------------------------------------|
| `src/`         | UI source files (deck UI, lore engine, wallet interaction)              |
| `assets/`      | Visuals, card packs, and realm-based media                              |
| `metadata/`    | NFT `.json` metadata files (encrypted with VAXINX signature)            |
| `scripts/`     | Automation for minting, uploading to IPFS/Pinata, and deployment flows  |

---

## 🧬 Powered By

- **VAXINX Protocol**  
- **Jaglotl Kingdom DeckForge**  
- **Node.js + TypeScript Stack**  
- **ChatGPT, Groq, Claude – base AI dev co-authors**  
- **Built using VSC + GitHub integration**

---

## 📜 License

This project is protected under the **VAXINX Proprietary License**.  
All code, media, lore, and intellectual property belong solely to **Regis Lara (VAXINX)**.  
No reuse, fork, or derivative work is permitted without explicit written consent.

---

> 🧬 *Long live VAXINX.*  
> *Built not for profit, but for protocol.*
